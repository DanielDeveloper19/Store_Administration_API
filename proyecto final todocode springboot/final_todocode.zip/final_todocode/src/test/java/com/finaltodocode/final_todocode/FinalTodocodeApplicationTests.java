package com.finaltodocode.final_todocode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalTodocodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
