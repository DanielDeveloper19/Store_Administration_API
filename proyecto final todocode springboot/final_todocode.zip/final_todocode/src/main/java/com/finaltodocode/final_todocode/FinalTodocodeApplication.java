package com.finaltodocode.final_todocode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalTodocodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalTodocodeApplication.class, args);
	}

}
